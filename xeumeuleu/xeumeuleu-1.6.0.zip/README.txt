XeuMeuLeu is an open-source cross-platform C++ stream oriented interface on top
of Apache Xerces for manipulating XML and Apache Xalan for applying XSL transformations.

For more information see http://xeumeuleu.sf.net

Apache Xerces and Apache Xalan are subject to the Apache License Version 2.0, see http://www.apache.org/licenses/LICENSE-2.0.html
For more information on Apache Xerces see http://xerces.apache.org/xerces-c
For more information on Apache Xalan see http://xml.apache.org/xalan-c
